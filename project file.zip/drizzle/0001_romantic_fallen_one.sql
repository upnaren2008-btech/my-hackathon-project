ALTER TABLE `availabilityIntervals` ADD `ownerOpenId` varchar(64) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `studyParticipants` ADD `ownerOpenId` varchar(64) DEFAULT '' NOT NULL;