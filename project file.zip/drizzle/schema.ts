import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const studyParticipants = mysqlTable("studyParticipants", {
  id: int("id").autoincrement().primaryKey(),
  groupName: varchar("groupName", { length: 120 }).notNull(),
  ownerOpenId: varchar("ownerOpenId", { length: 64 }).notNull().default(""),
  name: varchar("name", { length: 120 }).notNull(),
  color: varchar("color", { length: 32 }).notNull().default("#789C88"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const availabilityIntervals = mysqlTable("availabilityIntervals", {
  id: int("id").autoincrement().primaryKey(),
  participantId: int("participantId").notNull(),
  groupName: varchar("groupName", { length: 120 }).notNull(),
  ownerOpenId: varchar("ownerOpenId", { length: 64 }).notNull().default(""),
  startsAt: timestamp("startsAt").notNull(),
  endsAt: timestamp("endsAt").notNull(),
  timezone: varchar("timezone", { length: 64 }).notNull().default("UTC"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StudyParticipant = typeof studyParticipants.$inferSelect;
export type InsertStudyParticipant = typeof studyParticipants.$inferInsert;
export type AvailabilityInterval = typeof availabilityIntervals.$inferSelect;
export type InsertAvailabilityInterval = typeof availabilityIntervals.$inferInsert;