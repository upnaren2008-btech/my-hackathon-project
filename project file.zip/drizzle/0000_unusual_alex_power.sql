CREATE TABLE `availabilityIntervals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`participantId` int NOT NULL,
	`groupName` varchar(120) NOT NULL,
	`startsAt` timestamp NOT NULL,
	`endsAt` timestamp NOT NULL,
	`timezone` varchar(64) NOT NULL DEFAULT 'UTC',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `availabilityIntervals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `studyParticipants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`groupName` varchar(120) NOT NULL,
	`name` varchar(120) NOT NULL,
	`color` varchar(32) NOT NULL DEFAULT '#789C88',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `studyParticipants_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
