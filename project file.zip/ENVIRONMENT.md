# Environment and deployment configuration

StudySync is a React/Vite frontend served by an Express Node application with tRPC procedures, Drizzle ORM, MySQL/TiDB persistence, and Manus OAuth.

## Required variables

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | MySQL/TiDB connection string for Drizzle. |
| `JWT_SECRET` | Long random value used to sign sessions. |
| `VITE_APP_ID` | Manus OAuth application identifier. |
| `VITE_OAUTH_PORTAL_URL` | Browser-facing OAuth portal URL. |
| `OAUTH_SERVER_URL` | Server-side OAuth API base URL. |
| `BUILT_IN_FORGE_API_URL` and `BUILT_IN_FORGE_API_KEY` | Server-side built-in service access. |
| `VITE_FRONTEND_FORGE_API_URL` and `VITE_FRONTEND_FORGE_API_KEY` | Browser-facing built-in service access when required. |
| `OWNER_OPEN_ID` and `OWNER_NAME` | Project owner identity used by the auth layer. |
| `VITE_ANALYTICS_ENDPOINT` and `VITE_ANALYTICS_WEBSITE_ID` | Optional analytics configuration. |

Values must be provided through the deployment environment or the project’s secret manager. Never commit `.env`, `.env.local`, production credentials, API keys, or private OAuth values. The repository ignore rules exclude local environment files and build/log artifacts.

## Commands

Use `pnpm install`, `pnpm check`, `pnpm test`, and `pnpm build` locally. Apply the reviewed Drizzle migrations before first production start. The production process is `NODE_ENV=production node dist/index.js`, and the build command is `vite build && esbuild server/_core/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist`.

## Hosting recommendation

Use Manus WebDev hosting in Autoscale mode for the current full-stack Node application. It already understands the project’s managed environment, tRPC gateway, database, OAuth, checkpoints, and custom-domain flow. Reserved hosting is only necessary if later usage requires continuously warm instances or long-running background work.

## Planning window

The current product policy is an unrestricted planning window: `planningWindow` in `client/src/lib/calendar.ts` has nullable `minDate` and `maxDate` values, both set to `null`, so August 2026, September 2026, later months, and future years remain selectable. If a business rule is introduced, set these ISO date keys centrally rather than adding month-specific conditions.

## Security boundary

Availability procedures are protected by authenticated tRPC procedures. Before public launch, add explicit group membership or invitation-token checks so an authenticated user can only read or mutate groups they belong to. The current group-name lookup is suitable for the prototype but should not be treated as the final authorization model.
