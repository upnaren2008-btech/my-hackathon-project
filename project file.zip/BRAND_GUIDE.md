# SyncGaze Orbit Sync logo guide

## Concept

Orbit Sync uses three converging orbital arcs and a central spark to represent separate schedules aligning into one shared study moment.

## Usage

Use the standalone mark in the website header, browser favicon, and compact product surfaces. Pair it with the existing Fraunces wordmark treatment for the primary brand lockup. Keep the mark optically centered and preserve clear space equal to the central spark’s height around the symbol.

## Color roles

Deep ink navy provides the structural base, Daybreak Orange marks the focal spark and primary action moments, and Sage Green supports the collaborative orbit. Do not add extra gradients, shadows, or dense detail at favicon scale.

## Accessibility and scaling

Use the mark on a light parchment surface or inside the navy rounded-square header container. At small sizes, the central spark and the three orbit silhouettes should remain distinguishable. The browser favicon references the same generated Orbit Sync asset as the in-app header.
