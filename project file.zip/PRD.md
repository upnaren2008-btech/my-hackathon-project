# StudySync — Product Requirements Document

**Problem:** Hackathon Problem 12 — Group Study-Session Scheduler  
**Product:** StudySync  
**Author:** Manus AI  
**Status:** Hackathon prototype specification  
**Primary audience:** Student groups coordinating shared study time

## 1. Executive summary

StudySync helps a group of students find one study time that everyone can realistically attend. Each person contributes a handful of free-time windows, and the product turns those individual inputs into one ranked, explainable recommendation. The core experience is intentionally small: create a circle, add contributors, mark availability, reveal the best overlap, and share the resulting plan.

The product should not feel like another poll or calendar. Its differentiator is the “best overlap” moment: one clear answer, accompanied by a simple explanation of who is free, how long the session can run, and whether conflicts remain. The journey is deliberately staged as **setup → person-by-person preferences → combined availability → best overlap → share**.

## 2. User problem

Student groups lose time negotiating because each person communicates availability differently. A chat thread produces fragmented replies, a poll produces several competing options, and a calendar can be too heavy for a one-off study session. The user needs a fast coordination layer that preserves flexibility while making a confident recommendation.

> **Design principle:** The product should reduce coordination overhead without asking students to learn a new scheduling system.

## 3. Goals and non-goals

| Goals | Non-goals for the hackathon prototype |
|---|---|
| Let a group provide availability in under two minutes. | Full calendar synchronization with Google or Microsoft accounts. |
| Calculate and show the strongest common slot. | Notifications, recurring schedules, or institutional integrations. |
| Explain why the recommendation won. | Production-grade authentication and permissions. |
| Make the result easy to share. | Complex optimization across months of schedules. |
| Present a memorable, polished demo. | Building a native mobile application. |

## 4. Target users

The primary persona is **Aarav**, a university student coordinating a three-to-six-person study group before an exam. Aarav wants a decision quickly and does not want to chase replies. Secondary users are group members who need a low-friction way to mark when they can attend, often from a phone.

## 5. Core user journey

| Stage | User action | Product response |
|---|---|---|
| Create | Name a circle, such as “Signals & Systems.” | The workspace opens with a visible group context. |
| Contribute | Add names and toggle free-time windows. | Availability strips update immediately. |
| Recommend | Select “Find my best time.” | The highest-fit overlap is promoted with a concise rationale. |
| Decide | Review the people, duration, and conflict state. | The group has one clear decision instead of a thread. |
| Share | Copy the plan. | A simple shareable sentence is placed on the clipboard. |

## 6. Functional requirements

### 6.0 Planning setup and individual preferences

Before the shared availability board, the user selects the expected group size and preferred session duration. The interface then presents each member as a separate contributor tab. For the active member, the user can choose a preferred clock time and toggle individual day windows between free and busy. The product keeps those inputs attached to that member, then aggregates all contributor windows to rank the best shared day. This makes the recommendation traceable: every result is built from visible person-by-person choices.

### 6.0.1 Motivational flash cards

Every meaningful planning advance should surface a motivational quote in a flash-card treatment. The card uses a small rotating palette of warm yellow, sage, and blush surfaces, includes a “Next card” interaction, and changes to a new quote without reloading the page. The flash card should feel like a collectible planning note rather than a static subtitle.

### 6.1 Circle setup

The user can edit the circle name, see the number of contributors, add a person, and receive confirmation when a person is added. The interface should support keyboard entry and Enter-to-add behavior.

### 6.2 Availability input

Each contributor has a row of clearly labeled day windows. A user can toggle a window between available and not available. The visual language should distinguish “free” from “not available” without requiring a legend after the first interaction. The prototype uses representative sample data so the demo opens in a populated state.

### 6.3 Recommendation

The recommendation card should communicate the selected day, time, session length, contributor count, and conflict state. It should also list each contributor’s contribution to the recommendation. The recommendation should be visually dominant and explainable rather than hidden behind a secondary screen.

### 6.4 Share action

The “Copy the plan” action copies a concise plan to the clipboard and shows visible confirmation. If clipboard permissions are unavailable, the product should still show a confirmation toast for the demo and preserve the plan on screen.

### 6.5 Empty and error states

If no person is added, the product should prompt for a name. If a user tries to add an empty name, it should show a clear inline toast. If all windows are removed, the recommendation area should explain that the group needs at least one overlapping window before a plan can be made. These states are the next implementation increment after the polished happy path.

## 7. Recommendation logic for the MVP

Represent each person’s availability as a set of discrete windows. For every candidate window, count how many contributors are available. Rank candidates by contributor count, then by preferred session duration, then by earliest date/time. A production version could add weighting for required attendees, time-zone normalization, or personal preferences.

For the hackathon demo, the deterministic sample data should produce **Wednesday at 4:00 PM** as the top result for three contributors. This makes the live story reliable while the toggles demonstrate that the interface is interactive.

## 8. UX and visual requirements

StudySync follows the **Warm Editorial Planner** direction. It uses parchment as the canvas, ink navy for structure, sage for ordinary availability, and Daybreak Orange only for the strongest overlap and primary actions. The composition should feel like an editorial pinboard: a large recommendation, anchored context, availability strips, and compact explanatory notes.

The interface must remain legible on small screens. Touch targets should be generous, focus states visible, contrast sufficient, and all availability cells labeled for assistive technology. Motion should be short and purposeful, with reduced-motion support.

## 9. Hackathon demo script

Begin with the problem in one sentence: “Study groups do not need another poll; they need one time everyone can keep.” Show the populated circle and point out that three people have contributed different windows. Toggle one window live to prove the interface is not a static mockup. Press “Find my best time,” then narrate the recommendation: “Wednesday at 4 PM wins because all three contributors are free for a 90-minute session, with no conflict detected.” Add a fourth person to show the flow scales. Finish by copying the plan and showing the confirmation.

The whole demo should take approximately ninety seconds. Keep the story anchored on the before-and-after contrast: scattered availability becomes a clear plan.

## 10. How to maximize placement potential

Judges typically remember teams that make the problem obvious, show a working end-to-end flow, and connect the solution to a believable user benefit. StudySync should therefore optimize for **clarity, visible computation, and finish quality** rather than a large feature list.

| Judging signal | How StudySync should demonstrate it |
|---|---|
| Problem clarity | Open with the coordination pain and a concrete student scenario. |
| Innovation | Position “best overlap” as an explainable decision, not a poll result. |
| Execution | Use a live, clickable flow with populated sample data and immediate state changes. |
| User experience | Keep the interface focused on one action per stage and make the result visually obvious. |
| Impact | Explain that every avoided scheduling loop gives the group more time to study. |
| Technical credibility | Briefly explain the availability model, ranking logic, and how the design can extend to real calendars. |

Do not overclaim adoption, accuracy, or real-time integrations that are not implemented. A precise prototype with a confident explanation is more persuasive than a broad but shallow product.

## 11. Suggested technical implementation

For the hackathon frontend, implement the experience as a React single-page application with local state for the circle, contributors, availability windows, recommendation state, and share action. Keep the recommendation logic in a small pure function so it can later move to a backend without changing the interface. Use accessible buttons for availability cells, semantic headings, keyboard support, and a toast system for confirmations.

For a post-hackathon version, add persisted circles, invitation links, time-zone handling, calendar import, optional required attendees, and notifications. These should come after validating that students actually prefer a ranked recommendation over a traditional poll.

## 12. Acceptance criteria

| Requirement | Acceptance test |
|---|---|
| Add contributor | Enter a name and press Add or Enter; the roster count and row update. |
| Toggle availability | Click a cell; its state and accessible label change immediately. |
| Generate recommendation | Click the primary CTA; the best-overlap card is highlighted and scrolled into view. |
| Explain result | The recommendation shows contributor count, duration, and a per-person rationale. |
| Copy plan | Click Copy the plan; a confirmation is shown and clipboard text is populated when permitted. |
| Responsive layout | The page remains usable at mobile width without horizontal content loss. |
| Visual quality | Typography, palette, spacing, imagery, and motion consistently follow the Warm Editorial Planner direction. |

## 13. Design and frontend resources

For UI/UX, start with the included `ideas.md` as the design brief, then turn the core journey into a low-fidelity flow: **Circle → Availability → Best overlap → Share**. A Figma file is useful if the team needs to collaborate on screens, but it is not required for a strong hackathon submission. You can create the visual system directly in the frontend once the typography, color tokens, spacing rhythm, component states, and mobile behavior are documented.

For frontend implementation, use the existing StudySync prototype as the starting point. It already includes a branded landing/dashboard surface, editable circle name, add-person flow, interactive availability cells, recommendation state, and copy-plan action. The next production increment is to extract the recommendation calculation into a reusable function and add a real empty state.

## 14. Final recommendation

Build less, but make the one important moment undeniable. If the judges can understand the problem in ten seconds, see the inputs change in real time, and watch StudySync turn them into one defensible plan in under two minutes, the project will present as focused, useful, and thoughtfully executed.
