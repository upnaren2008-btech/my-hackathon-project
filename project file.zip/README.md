# StudySync

StudySync helps a study circle compare exact free-time intervals and choose a continuous group-study slot. Members can select a date, add multiple free periods, edit or delete them, choose a minimum session duration, inspect participant-colored timelines, and select a ranked overlap for planning.

## Technology

The application is a React 19 and Vite frontend served by an Express 4 Node application. It uses tRPC 11 for typed API contracts, Drizzle ORM with MySQL/TiDB for persistence, Manus OAuth for authentication, Tailwind CSS for styling, and Vitest for automated tests.

## Local development

Install dependencies with `pnpm install`. Start the application with `pnpm dev`, then run `pnpm check`, `pnpm test`, and `pnpm build` before sharing a build. Configure the variables listed in `ENVIRONMENT.md` through the local environment or the project secret manager; never commit actual credentials.

## Database

The scheduling schema is defined in `drizzle/schema.ts`. The current migration creates `studyParticipants` and `availabilityIntervals` alongside the auth `users` table. For a new environment, review generated SQL, apply the migration, and verify the connection before starting the server.

## Production deployment

Use Manus WebDev hosting for this full-stack Node project. Create a checkpoint, configure the required environment variables, apply the database migration, and use the project’s Publish action. The production build is `pnpm build`; the start command is `NODE_ENV=production node dist/index.js`. Autoscale is appropriate for the current request/response workload. Consider Reserved hosting only if the application later needs continuously warm instances or long-running background work.

## Project structure

`client/src/pages/Home.tsx` contains the scheduling interface. `client/src/lib/availability.ts` contains pure exact interval-ranking logic. `server/routers.ts` exposes protected availability procedures, `server/db.ts` contains Drizzle helpers, and `drizzle/schema.ts` defines persistence. `ENVIRONMENT.md` contains deployment configuration and security notes.

## Security

Availability procedures require authentication. Before a public launch, add group membership or invitation-token authorization rather than relying on a group-name query alone. Keep session secrets, OAuth credentials, database credentials, built-in service keys, and analytics identifiers outside the repository. The current browser-local fallback is explicitly labeled for the hackathon demo and should be removed or disabled after the authenticated invitation flow becomes the default.

## Validation

The repository includes automated coverage for exact intersections, merged continuous overlaps, minimum duration, no-full-group overlap, ranking priority, and same-person conflict detection. The responsive UI has been manually checked at desktop and narrow mobile widths.
