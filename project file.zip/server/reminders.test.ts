import { describe, expect, it } from "vitest";
import { parseStoredReminder, reminderMessage, reminderReplacementMessage, reminderTimeValid, shouldClearStoredReminder } from "../client/src/lib/reminders";

describe("browser reminders", () => {
  it("accepts only future reminder times", () => {
    const now = new Date("2026-08-28T10:00:00").getTime();
    expect(reminderTimeValid({ reminderAt: "2026-08-28T10:30", now })).toBe(true);
    expect(reminderTimeValid({ reminderAt: "2026-08-28T09:30", now })).toBe(false);
    expect(reminderTimeValid({ reminderAt: "not-a-date", now })).toBe(false);
  });
  it("restores only future stored reminders", () => {
    const now = 1_000;
    const reminder = { fireAt: 2_000, title: "Study" };
    expect(parseStoredReminder<typeof reminder>(JSON.stringify(reminder), now)).toEqual(reminder);
    expect(parseStoredReminder<typeof reminder>(JSON.stringify({ ...reminder, fireAt: 900 }), now)).toBeNull();
    expect(parseStoredReminder<typeof reminder>("broken", now)).toBeNull();
  });
  it("clears expired and malformed stored reminders at the persistence boundary", () => {
    const now = 1_000;
    expect(shouldClearStoredReminder(JSON.stringify({ fireAt: 900 }), now)).toBe(true);
    expect(shouldClearStoredReminder("broken", now)).toBe(true);
    expect(shouldClearStoredReminder(JSON.stringify({ fireAt: 2_000 }), now)).toBe(false);
    expect(shouldClearStoredReminder(null, now)).toBe(false);
  });
  it("explains when a new reminder replaces an existing one", () => {
    expect(reminderReplacementMessage(true)).toContain("replaced");
    expect(reminderReplacementMessage(false)).toContain("scheduled");
  });
  it("builds a concise group reminder message", () => {
    expect(reminderMessage("Signals review", "Friday, August 28", "4:00 PM")).toContain("Signals review");
    expect(reminderMessage("", "Friday, August 28", "4:00 PM")).toContain("Group study session");
  });
});
