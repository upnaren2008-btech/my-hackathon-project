import { describe, expect, it } from "vitest";
import { studyQuotes } from "../client/src/lib/quotes";
import { confirmedPlanSummary } from "../client/src/lib/confirmation";
import { nextQuoteIndex, previousQuoteIndex, quoteCollectionIsReady, quoteRoomUrl } from "../client/src/lib/quoteRoom";

describe("quote room", () => {
  it("keeps the uploaded s4.py collection intact and non-empty", () => {
    expect(studyQuotes.length).toBe(50);
    expect(quoteCollectionIsReady(studyQuotes)).toBe(true);
  });
  it("builds the confirmation destination for the selected plan", () => {
    expect(quoteRoomUrl("2026-09-07", 3)).toBe("/quotes?date=2026-09-07&people=3");
  });
  it("summarizes the confirmed plan for the main scheduler", () => {
    expect(confirmedPlanSummary({ date: "2026-09-07", start: 900, end: 990, count: 3 }, 4)).toEqual({ availableLabel: "3/4 participants", quotePath: "/quotes?date=2026-09-07&people=4" });
  });
  it("wraps forward and backward navigation", () => {
    expect(nextQuoteIndex(studyQuotes.length - 1, studyQuotes.length)).toBe(0);
    expect(previousQuoteIndex(0, studyQuotes.length)).toBe(studyQuotes.length - 1);
    expect(nextQuoteIndex(4, studyQuotes.length)).toBe(5);
  });
});
