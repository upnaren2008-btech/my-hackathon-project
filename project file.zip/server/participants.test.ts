import { describe, expect, it } from "vitest";
import { resizeParticipantNames, validateParticipantNames } from "../client/src/lib/participants";

describe("participant setup", () => {
  it("trims valid participant names", () => {
    expect(validateParticipantNames([" Alice ", "Bob"]).names).toEqual(["Alice", "Bob"]);
  });
  it("generates names for new participants and trims on resize", () => {
    expect(resizeParticipantNames(["Alice", "Bob"], 4)).toEqual(["Alice", "Bob", "Person 3", "Person 4"]);
    expect(resizeParticipantNames(["Alice", "Bob", "Charlie"], 2)).toEqual(["Alice", "Bob"]);
  });
  it("rejects blank names", () => {
    expect(validateParticipantNames(["Alice", " "]).valid).toBe(false);
  });
  it("rejects duplicate names case-insensitively", () => {
    expect(validateParticipantNames(["Alice", "alice"]).message).toContain("unique");
  });
});
