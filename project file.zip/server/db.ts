import { and, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, studyParticipants, availabilityIntervals } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function listStudyData(groupName: string, ownerOpenId: string) {
  const db = await getDb();
  if (!db) return { participants: [], intervals: [] };
  const participants = await db.select().from(studyParticipants).where(and(eq(studyParticipants.groupName, groupName), eq(studyParticipants.ownerOpenId, ownerOpenId)));
  const intervals = await db.select().from(availabilityIntervals).where(and(eq(availabilityIntervals.groupName, groupName), eq(availabilityIntervals.ownerOpenId, ownerOpenId)));
  return { participants, intervals };
}

export async function createParticipant(input: { groupName: string; name: string; color: string; ownerOpenId: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.insert(studyParticipants).values(input);
  const rows = await db.select().from(studyParticipants).where(and(eq(studyParticipants.groupName, input.groupName), eq(studyParticipants.name, input.name), eq(studyParticipants.ownerOpenId, input.ownerOpenId))).limit(1);
  return rows[0];
}

export async function createInterval(input: { participantId: number; groupName: string; ownerOpenId: string; startsAt: Date; endsAt: Date; timezone: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  if (input.startsAt >= input.endsAt) throw new Error("Start time must be before end time");
  await db.insert(availabilityIntervals).values(input);
  return input;
}

export async function deleteInterval(id: number, ownerOpenId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.delete(availabilityIntervals).where(and(eq(availabilityIntervals.id, id), eq(availabilityIntervals.ownerOpenId, ownerOpenId)));
  return { success: true };
}

export async function updateInterval(id: number, startsAt: Date, endsAt: Date, ownerOpenId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  if (startsAt >= endsAt) throw new Error("Start time must be before end time");
  await db.update(availabilityIntervals).set({ startsAt, endsAt }).where(and(eq(availabilityIntervals.id, id), eq(availabilityIntervals.ownerOpenId, ownerOpenId)));
  return { success: true };
}
