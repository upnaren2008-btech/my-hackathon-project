import { describe, expect, it } from "vitest";
import { dateKey, daysForMonth, isDateSelectableForNow, nextLocalHour, parseLocalDate, shiftMonth } from "../client/src/lib/calendar";

describe("dynamic calendar", () => {
  it("renders every day in August 2026", () => {
    const days = daysForMonth("2026-08").filter(Boolean);
    expect(days).toHaveLength(31);
    expect(days[0]).toBe("2026-08-01");
    expect(days.at(-1)).toBe("2026-08-31");
  });
  it("renders the first week and all later dates in September 2026", () => {
    const days = daysForMonth("2026-09").filter(Boolean);
    expect(days).toContain("2026-09-01");
    expect(days).toContain("2026-09-07");
    expect(days.at(-1)).toBe("2026-09-30");
  });
  it("navigates across years without special-case month logic", () => {
    expect(shiftMonth("2026-08", 1)).toBe("2026-09");
    expect(shiftMonth("2026-09", 1)).toBe("2026-10");
    expect(shiftMonth("2026-01", -1)).toBe("2025-12");
  });
  it("keeps a calendar date local and stable", () => {
    const date = parseLocalDate("2026-09-03");
    expect(dateKey(date)).toBe("2026-09-03");
  });
  it("blocks past dates but allows today and future dates", () => {
    const now = new Date(2026, 7, 28, 14, 30);
    expect(isDateSelectableForNow("2026-08-27", now)).toBe(false);
    expect(isDateSelectableForNow("2026-08-28", now)).toBe(true);
    expect(isDateSelectableForNow("2026-09-03", now)).toBe(true);
  });
  it("starts today at the next local hour and handles midnight safely", () => {
    expect(nextLocalHour(new Date(2026, 7, 28, 14, 30))).toBe(15);
    expect(nextLocalHour(new Date(2026, 7, 28, 14, 0))).toBe(14);
    expect(nextLocalHour(new Date(2026, 7, 28, 23, 59))).toBe(23);
  });
});
