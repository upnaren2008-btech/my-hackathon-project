import { describe, expect, it } from "vitest";
import { hasOverlap, rankSharedSlots } from "../client/src/lib/availability";

describe("group availability", () => {
  const intervals = [
    { participantId: 1, date: "2026-09-07", start: "09:00", end: "12:00" },
    { participantId: 2, date: "2026-09-07", start: "10:00", end: "13:00" },
    { participantId: 3, date: "2026-09-07", start: "11:00", end: "14:00" },
  ];

  it("finds the actual three-person intersection", () => {
    expect(rankSharedSlots(intervals, [1, 2, 3], 60)[0]).toMatchObject({ start: 660, end: 720, count: 3 });
  });

  it("rejects an overlap shorter than the required duration", () => {
    const short = [{ participantId: 1, date: "2026-09-07", start: "10:00", end: "11:00" }, { participantId: 2, date: "2026-09-07", start: "10:30", end: "11:30" }];
    expect(rankSharedSlots(short, [1, 2], 90)).toHaveLength(0);
  });

  it("returns no slots when participants never overlap", () => {
    const disjoint = [{ participantId: 1, date: "2026-09-07", start: "09:00", end: "10:00" }, { participantId: 2, date: "2026-09-07", start: "11:00", end: "12:00" }];
    expect(rankSharedSlots(disjoint, [1, 2], 30).every(slot => slot.count < 2)).toBe(true);
  });

  it("ranks the slot with more participants first", () => {
    const multiple = [...intervals, { participantId: 4, date: "2026-09-07", start: "11:00", end: "12:00" }];
    const ranked = rankSharedSlots(multiple, [1, 2, 3, 4], 30);
    expect(ranked[0]?.count).toBe(4);
  });

  it("prevents same-person overlapping periods", () => {
    expect(hasOverlap({ start: "09:00", end: "11:00" }, { start: "10:30", end: "12:00" })).toBe(true);
    expect(hasOverlap({ start: "09:00", end: "11:00" }, { start: "11:00", end: "12:00" })).toBe(false);
  });
});
