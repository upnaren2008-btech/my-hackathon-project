import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createInterval, createParticipant, deleteInterval, listStudyData, updateInterval } from "./db";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  availability: router({
    list: protectedProcedure.input(z.object({ groupName: z.string().min(1).max(120) })).query(({ input, ctx }) => listStudyData(input.groupName, ctx.user.openId)),
    addParticipant: protectedProcedure.input(z.object({ groupName: z.string().min(1), name: z.string().min(1).max(120), color: z.string().min(4).max(32) })).mutation(({ input, ctx }) => createParticipant({ ...input, ownerOpenId: ctx.user.openId })),
    addInterval: protectedProcedure.input(z.object({ participantId: z.number().int().positive(), groupName: z.string().min(1), startsAt: z.coerce.date(), endsAt: z.coerce.date(), timezone: z.string().default("UTC") })).mutation(({ input, ctx }) => createInterval({ ...input, ownerOpenId: ctx.user.openId })),
    updateInterval: protectedProcedure.input(z.object({ id: z.number().int().positive(), startsAt: z.coerce.date(), endsAt: z.coerce.date() })).mutation(({ input, ctx }) => updateInterval(input.id, input.startsAt, input.endsAt, ctx.user.openId)),
    deleteInterval: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input, ctx }) => deleteInterval(input.id, ctx.user.openId)),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
