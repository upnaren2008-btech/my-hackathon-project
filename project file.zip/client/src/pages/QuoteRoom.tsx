import { useEffect, useState } from "react";
import { Check, ChevronLeft, ChevronRight, Copy, Sparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { studyQuotes } from "@/lib/quotes";
import { nextQuoteIndex, previousQuoteIndex } from "@/lib/quoteRoom";

export default function QuoteRoom() {
  const params = new URLSearchParams(window.location.search);
  const date = params.get("date");
  const people = Number(params.get("people") || 0);
  const [index, setIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const quote = studyQuotes[index];
  const close = () => window.close();
  const copy = async () => { try { await navigator.clipboard.writeText(quote); setCopied(true); toast.success("Quote copied"); window.setTimeout(() => setCopied(false), 1200); } catch { toast.error("Copy is unavailable in this browser"); } };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") close(); if (event.key === "ArrowRight") setIndex(value => nextQuoteIndex(value, studyQuotes.length)); if (event.key === "ArrowLeft") setIndex(value => previousQuoteIndex(value, studyQuotes.length)); };
    window.addEventListener("keydown", onKey); return () => window.removeEventListener("keydown", onKey);
  }, []);

  return <main className={`min-h-screen p-5 text-[#16263D] md:p-10 ${index % 3 === 0 ? "bg-[#FFF3D8]" : index % 3 === 1 ? "bg-[#DCEBE2]" : "bg-[#F5D9CE]"}`}>
    <div className="mx-auto max-w-3xl"><div className="flex items-start justify-between gap-4"><div><div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[.18em] text-[#B94724]"><Sparkles className="h-4 w-4" /> StudySync · quote room</div><h1 className="mt-3 font-serif text-5xl font-bold leading-[.95] tracking-[-.06em] md:text-7xl">A little fuel<br />for the circle.</h1><p className="mt-5 max-w-xl text-sm leading-6 text-[#16263D]/65">{date ? `Your group matched ${date}.` : "Your group found a shared moment."} {people ? `${people} minds, one next step.` : "Take one thought with you."}</p></div><button type="button" onClick={close} aria-label="Close quote room" className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-[#16263D]/10"><X className="h-5 w-5" /></button></div>
      <section className="mt-12 rounded-[2rem] border border-[#16263D]/10 bg-[#FFFDF9]/80 p-7 shadow-[0_22px_55px_rgba(22,38,61,.12)] md:p-12"><div className="flex items-center justify-between text-xs font-bold uppercase tracking-[.15em] text-[#16263D]/45"><span>Card {index + 1} of {studyQuotes.length}</span><span>← / → navigate</span></div><blockquote className="mt-10 font-serif text-4xl font-bold leading-[1.05] tracking-[-.05em] md:text-6xl">“{quote}”</blockquote><div className="mt-12 flex flex-wrap items-center justify-between gap-3"><div className="flex gap-2"><Button type="button" variant="outline" onClick={() => setIndex(value => previousQuoteIndex(value, studyQuotes.length))} className="rounded-full bg-[#FFFDF9]"><ChevronLeft className="mr-1 h-4 w-4" /> Previous</Button><Button type="button" onClick={() => setIndex(value => nextQuoteIndex(value, studyQuotes.length))} className="rounded-full bg-[#16263D] text-[#F7F2EA]">Next card <ChevronRight className="ml-1 h-4 w-4" /></Button></div><Button type="button" variant="outline" onClick={copy} className="rounded-full bg-[#FFFDF9]">{copied ? <Check className="mr-2 h-4 w-4" /> : <Copy className="mr-2 h-4 w-4" />} {copied ? "Copied" : "Copy quote"}</Button></div></section><p className="mt-6 text-center text-xs font-semibold text-[#16263D]/45">Source: your uploaded s4.py quote collection · Press Esc to close</p></div>
  </main>;
}
