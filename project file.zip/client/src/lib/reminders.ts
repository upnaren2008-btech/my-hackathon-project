export type ReminderDraft = { reminderAt: string; now?: number };
export const reminderTimeValid = ({ reminderAt, now = Date.now() }: ReminderDraft) => { const fireAt = new Date(reminderAt).getTime(); return Number.isFinite(fireAt) && fireAt > now; };
export const reminderMessage = (title: string, date: string, time: string) => `${title || "Group study session"} · ${date} at ${time}`;
export const parseStoredReminder = <T extends { fireAt: number }>(raw: string | null, now = Date.now()): T | null => { if (!raw) return null; try { const parsed = JSON.parse(raw) as T; return parsed.fireAt > now ? parsed : null; } catch { return null; } };
export const reminderReplacementMessage = (hasExisting: boolean) => hasExisting ? "The previous reminder was replaced with this new one" : "Study session planned and reminder scheduled";
export const shouldClearStoredReminder = (raw: string | null, now = Date.now()) => raw !== null && parseStoredReminder(raw, now) === null;
