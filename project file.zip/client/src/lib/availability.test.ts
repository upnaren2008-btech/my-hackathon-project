import { describe, expect, it } from "vitest";
import { hasOverlap, rankSharedSlots } from "./availability";

describe("availability ranking", () => {
  const intervals = [
    { participantId: 1, date: "2026-09-07", start: "09:00", end: "12:00" },
    { participantId: 2, date: "2026-09-07", start: "10:00", end: "13:00" },
    { participantId: 3, date: "2026-09-07", start: "11:00", end: "14:00" },
  ];
  it("finds the shared intersection for all participants", () => {
    const slots = rankSharedSlots(intervals, [1, 2, 3], 60);
    expect(slots[0]).toMatchObject({ start: 11 * 60, end: 12 * 60, count: 3 });
  });
  it("does not return windows shorter than the required duration", () => {
    const slots = rankSharedSlots(intervals, [1, 2, 3], 90);
    expect(slots.every(slot => slot.end - slot.start >= 90)).toBe(true);
  });
  it("detects same-person interval conflicts", () => {
    expect(hasOverlap({ start: "09:00", end: "11:00" }, { start: "10:30", end: "12:00" })).toBe(true);
    expect(hasOverlap({ start: "09:00", end: "11:00" }, { start: "11:00", end: "12:00" })).toBe(false);
  });
});
