import { quoteRoomUrl } from "@/lib/quoteRoom";

export type ConfirmedSlot = { date: string; start: number; end: number; count: number };

export const confirmedPlanSummary = (slot: ConfirmedSlot, participantCount: number) => ({
  availableLabel: `${slot.count}/${participantCount} participants`,
  quotePath: quoteRoomUrl(slot.date, participantCount),
});
