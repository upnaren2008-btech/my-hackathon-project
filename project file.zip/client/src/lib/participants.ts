export const validateParticipantNames = (names: string[]) => {
  const cleaned = names.map(name => name.trim());
  if (cleaned.some(name => !name)) return { valid: false as const, message: "Give every participant a name" };
  if (new Set(cleaned.map(name => name.toLocaleLowerCase())).size !== cleaned.length) return { valid: false as const, message: "Participant names must be unique" };
  return { valid: true as const, names: cleaned };
};

export const resizeParticipantNames = (names: string[], nextSize: number) => Array.from({ length: nextSize }, (_, index) => names[index] ?? `Person ${index + 1}`);
