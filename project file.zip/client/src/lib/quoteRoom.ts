export const nextQuoteIndex = (index: number, total: number) => total === 0 ? 0 : (index + 1) % total;
export const previousQuoteIndex = (index: number, total: number) => total === 0 ? 0 : (index - 1 + total) % total;
export const quoteCollectionIsReady = (quotes: readonly string[]) => quotes.length >= 50 && quotes.every(quote => quote.trim().length > 0);
export const quoteRoomUrl = (date: string, people: number) => `/quotes?date=${encodeURIComponent(date)}&people=${people}`;
