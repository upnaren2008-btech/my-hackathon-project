export type AvailabilityInterval = { participantId: number; date: string; start: string; end: string };
export type RankedSlot = { start: number; end: number; count: number; participantIds: number[] };

const toMinutes = (value: string) => { const [hour, minute] = value.split(":").map(Number); return hour * 60 + minute; };

export function rankSharedSlots(intervals: AvailabilityInterval[], participantIds: number[], duration: number): RankedSlot[] {
  const boundaries = Array.from(new Set(intervals.flatMap(item => [toMinutes(item.start), toMinutes(item.end)]))).sort((a, b) => a - b);
  const segments: RankedSlot[] = [];
  for (let index = 0; index < boundaries.length - 1; index++) {
    const start = boundaries[index];
    const end = boundaries[index + 1];
    const available = participantIds.filter(participantId => intervals.some(item => item.participantId === participantId && toMinutes(item.start) <= start && toMinutes(item.end) >= end));
    if (!available.length) continue;
    const previous = segments[segments.length - 1];
    if (previous && previous.end === start && previous.participantIds.join(",") === available.join(",")) previous.end = end;
    else segments.push({ start, end, count: available.length, participantIds: available });
  }
  return segments.filter(slot => slot.end - slot.start >= duration).sort((a, b) => b.count - a.count || b.end - b.start - (a.end - a.start) || a.start - b.start).slice(0, 10);
}

export function hasOverlap(a: { start: string; end: string }, b: { start: string; end: string }) {
  return toMinutes(a.start) < toMinutes(b.end) && toMinutes(a.end) > toMinutes(b.start);
}
