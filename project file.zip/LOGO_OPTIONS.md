# SyncGaze logo options

| Option | Icon implication | Wordmark implication | Color implication | Favicon implication |
|---|---|---|---|---|
| Orbit Sync | Three converging arcs and a central spark express schedules aligning. | Pair with a calm serif SyncGaze wordmark and generous tracking. | Ink navy is the structure; orange owns the spark; sage supports the orbit. | Strong at small sizes because the arcs form a compact circular silhouette. |
| Shared Gaze | Two overlapping forms create an abstract shared eye and time point. | Use a friendly rounded wordmark with a slightly open letter spacing. | Navy and orange create focus; sage can soften the overlap. | Recognizable as an eye-like symbol, but the internal time point must remain simple. |
| Time Bridge | Two anchors joined by a curved bridge express meeting across free-time gaps. | Use a grounded, humanist wordmark with short proportions. | Orange can mark the bridge; navy anchors the people; sage supports the connection. | Works best as a simplified two-anchor bridge without small internal detail. |
| Constellation | Connected nodes express a group becoming one coordinated plan. | Use a slightly technical wordmark with clear, geometric forms. | Orange highlights the chosen shared slot while navy and sage show the network. | A three-node triangle remains legible and can scale cleanly. |
| Signal Lens | A rounded lens with aligned signals expresses clarity from scattered inputs. | Use a modern sans wordmark to reinforce a productivity-tool feel. | Navy gives precision; orange marks the strongest signal; sage provides calm contrast. | The outer lens shape gives a strong app-icon container. |

## Selected direction

SyncGaze uses **Orbit Sync**. Its circular silhouette is easy to recognize in a favicon, while the converging arcs directly describe the product’s scheduling promise. The central Daybreak Orange spark is reserved for the shared moment and primary action, with Ink Navy and Sage Green carrying the supporting identity.
