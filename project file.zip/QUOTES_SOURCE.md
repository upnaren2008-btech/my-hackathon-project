# StudySync quote source

The quote collection in `client/src/lib/quotes.ts` was transcribed from the user-uploaded `s4.py` file. The original Python program selects one quote randomly for each participant. StudySync adapts that source into a navigable quote room that opens after a shared study slot is selected.

The quote room supports previous/next navigation, copy-to-clipboard, keyboard-reachable controls, and responsive color-changing cards. No additional quotations were invented or mixed into the uploaded collection.
