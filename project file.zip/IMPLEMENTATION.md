# StudySync free-slot implementation notes

## What was wrong

The original feature exposed only dates and boolean-like free states. It did not let a person create multiple periods on the same date, inspect exact times, edit or delete a period, or see how intervals intersected across participants.

## What changed

The frontend now provides a selected-date schedule with a participant-colored timeline, exact start/end time inputs, add/edit/delete actions, same-person overlap validation, minimum study-duration controls, ranked shared slots, selected-slot highlighting, and a planning confirmation surface for topic and location. The API layer now includes participant and availability interval tables plus typed list/add/update/delete procedures.

## Real-time date eligibility

The calendar compares ISO date keys derived from local calendar parts. Dates before the local current date are disabled and rejected. When today is selected, the timeline begins at the next local hour boundary and interval saves reject windows that have already ended. Future dates begin at the normal planning-day start and remain fully selectable.

## Data model

An availability record contains `participantId`, `groupName`, `startsAt`, `endsAt`, and `timezone`. The database stores timestamp values. The UI hydrates from `trpc.availability.list` when persisted participant records exist and routes create, update, and delete interval actions through the typed procedures for those records. A browser-local fallback remains for the unauthenticated hackathon demo so the interface is immediately usable even before a group has been persisted.

## Overlap calculation

The tested ranking utility collects every interval boundary, sorts the boundaries, evaluates each exact adjacent segment, and counts which participants cover that whole segment. Segments shorter than the requested duration are excluded. Candidates are ranked by participant count, then by continuous duration, then by earlier start time. This avoids the previous fixed 30-minute stepping approximation.

## UI behavior

The user first chooses a date and study duration; the date-first design is deliberate, so the schedule always has a valid selected date and does not expose an unnecessary no-date state. Participant chips open a free-period editor for the selected person. The timeline shows all periods for the selected date. Clicking a block opens it for editing; adding a conflicting period or an end time before the start time produces a visible error. The best-slot panel shows up to three ranked candidates. Clicking a candidate selects it and highlights its time range on the timeline; the planning CTA then opens the confirmation form.

## Test coverage

Automated tests cover exact three-person intersection, minimum-duration rejection, no-overlap, multiple valid-slot ranking, same-person conflict detection, and existing authentication logout behavior. Manual responsive checks cover desktop and narrow mobile layouts. The UI includes loading/error feedback for the persisted query, no-availability, and no-overlap states.

## Participant setup and flashcards

The starting setup lets users choose a group size from two to eight people, generates one name field per participant, trims names, rejects blanks and case-insensitive duplicates, and filters removed participants’ local intervals when the group shrinks. The saved names drive participant chips, interval editors, overlap counts, and recommendation labels. The quote area stays in a locked prompt state until a shared slot is selected, then reveals the interactive color-changing flashcards.

## Browser reminders

After a user confirms a selected slot, StudySync can request browser notification permission and schedule a reminder for a future local date and time. The reminder is restored from browser-local storage after refresh, shown as an in-app toast, and sent through the browser Notification API when permission is granted. This first version intentionally does not send SMS, WhatsApp, or email and cannot guarantee delivery when the site is fully closed; reliable cross-device delivery would require web-push infrastructure and a user subscription flow.

## Honest prototype boundary

The interval database schema and typed server procedures are implemented and partially connected to the UI. The browser-local fallback is deliberate for the hackathon demo. For a production release, route participant creation through the API, remove the fallback after authentication and invitation flows are in place, and add server-side conflict checks plus full persisted plan records.
