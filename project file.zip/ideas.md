# StudySync design direction

## Three possible directions

### Theme Name: Warm Editorial Planner
Very Brief Intro: A calm, paper-like planning tool with ink-dark typography, citrus accents, and a tactile weekly planning ritual. It makes coordination feel thoughtful rather than administrative.
Probability: 0.07

### Theme Name: Quiet Campus Utility
Very Brief Intro: A bright, airy campus utility with soft blue surfaces, clear dashboards, and understated academic cues. It prioritizes clarity and low cognitive load.
Probability: 0.03

### Theme Name: Signal Grid
Very Brief Intro: A dark, high-contrast coordination console with vivid signal colors and live availability states. It makes overlap feel like a visible system snapping into place.
Probability: 0.09

## Chosen approach: Warm Editorial Planner

### Design Movement
Contemporary editorial interface design blended with analog stationery and Swiss information design: strong typographic hierarchy, restrained geometry, and a single expressive accent color.

### Core Principles
1. Make the group decision visible at a glance: a user should understand the recommended slot before reading the details.
2. Turn scheduling into a lightweight ritual: the interface should feel like arranging a shared plan, not filling out a form.
3. Use contrast with purpose: ink-dark type for confidence, warm paper surfaces for ease, and citrus orange only for the next action or best overlap.
4. Keep the system explainable: every recommendation should show why it was selected.

### Color Philosophy
The base is warm parchment rather than sterile white, creating a sense of calm and focus. Ink navy carries structure and trust. A saturated citrus orange called "Daybreak" marks the strongest shared slot and all primary actions. Sage and blush are used only as quiet status cues for availability and partial overlap.

### Layout Paradigm
A left rail anchors context while the main canvas behaves like a pinboard: one wide recommendation card, an overlap timeline, and a compact roster. The content is intentionally asymmetric, with the best slot occupying visual priority instead of a conventional centered dashboard.

### Signature Elements
- A small sunburst mark beside every recommended time.
- Editorial section labels in compact uppercase with generous tracking.
- Availability represented as tactile horizontal strips rather than dense tables.

### Interaction Philosophy
Interactions should feel like placing and rearranging paper notes. Inputs are direct, changes are immediate, and the recommendation updates with a concise explanation. The demo uses friendly sample data but makes the primary journey fully clickable.

### Animation
Use short, physical transitions: cards lift 2–4px on hover, the recommendation strip slides into place over 220ms, and availability segments fade/scale in with a 50ms stagger. Avoid constant motion. Respect reduced-motion preferences.

### Typography System
Use Fraunces for display headlines and section numerals, paired with DM Sans for body copy, labels, controls, and data. Headlines are tight and expressive; labels are uppercase and tracked; supporting copy remains generous and readable.

### Brand Essence
StudySync is the calm coordination layer for student groups who want to spend less time finding a time and more time learning together.
Personality: considered, warm, quietly clever.

### Brand Voice
Headlines sound decisive but human. CTAs describe the next useful action, never generic onboarding language. Microcopy explains the reasoning without making the user think harder.
Example lines: “Find the hour you can all keep.” and “Three people overlap here. Make it the plan.”

### Wordmark & Logo
The mark is a compact four-ray sunburst nested inside a rounded square, suggesting a shared hour snapping into focus. The wordmark uses a custom-feeling serif treatment with the “S” and “y” slightly tightened; the icon must remain recognizable without text.

### Signature Brand Color
Daybreak Orange: #F26A3D. It is energetic enough to prompt action but warm enough to remain friendly against parchment.

## Product vocabulary
- **Circle:** a study group.
- **Availability strip:** one person’s free-time contribution.
- **Best overlap:** the highest-fit shared slot.
- **Plan:** a confirmed study session.

## Build reminder
Every component should reinforce the Warm Editorial Planner direction. When in doubt, ask: “Does this choice make coordination feel calmer, clearer, and more human?”

## Style Decisions
- Daybreak Orange #F26A3D is reserved for primary actions, the best-overlap moment, and tiny signal marks; ordinary availability/status states use sage, blush, parchment, or ink instead.
- Availability should read as tactile horizontal planning strips or paper marks, never as a dense software calendar grid unless softened by stationery-like material treatment.
- StudySync compositions should feel like an editorial pinboard: one dominant recommendation, anchored context, and supporting notes arranged asymmetrically around it.
